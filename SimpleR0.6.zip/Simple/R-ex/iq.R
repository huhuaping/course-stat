### Name: iq
### Title: IQ scores
### Aliases: iq
### Keywords: datasets

### ** Examples

data(iq)
qqnorm(iq)



