### Name: simple.chutes
### Title: simulate a chutes and ladder game
### Aliases: simple.chutes
### Keywords: univar

### ** Examples

plot(simple.chutes(sim=TRUE))



