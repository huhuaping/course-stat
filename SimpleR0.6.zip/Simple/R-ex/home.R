### Name: home
### Title: Maplewood NJ homedata
### Aliases: home
### Keywords: datasets

### ** Examples

data(home)
## compare on the same scale
boxplot(data.frame(scale(home))) 



