### Name: ewr
### Title: Taxi in and taxi out times at EWR (Newark) airport for 1999-2001
### Aliases: ewr
### Keywords: datasets

### ** Examples

data(ewr)
boxplot(ewr[3:10])



