### Name: blood
### Title: blood pressure readings
### Aliases: blood
### Keywords: datasets

### ** Examples

data(blood)
attach(blood)
t.test(Machine,Expert)
detach(blood)



