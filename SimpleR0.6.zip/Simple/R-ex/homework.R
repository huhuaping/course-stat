### Name: homework
### Title: Homework averages for Private and Public schools
### Aliases: homework
### Keywords: datasets

### ** Examples

data(homework)
boxplot(homework)



