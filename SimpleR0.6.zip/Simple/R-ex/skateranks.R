### Name: skateranks
### Title: Judges scores for disputed ice skating competition
### Aliases: skateranks
### Keywords: datasets

### ** Examples

data(skateranks)



