### Name: puerto
### Title: Incomes for Puerto Rican immigrants to Miami
### Aliases: puerto
### Keywords: datasets

### ** Examples

data(puerto)
hist(puerto)



