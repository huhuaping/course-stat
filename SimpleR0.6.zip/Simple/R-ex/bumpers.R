### Name: bumpers
### Title: bumper repair costs
### Aliases: bumpers
### Keywords: datasets

### ** Examples

data(bumpers)
stem(bumpers)



