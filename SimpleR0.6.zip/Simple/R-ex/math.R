### Name: math
### Title: Standardized math scores
### Aliases: math
### Keywords: datasets

### ** Examples

data(math)
hist(math)



