### Name: exec.pay
### Title: Direct compensation for 200 United States CEO's for 2000
### Aliases: exec.pay
### Keywords: datasets

### ** Examples

data(exec.pay)
hist(exec.pay)



