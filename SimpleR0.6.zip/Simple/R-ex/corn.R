### Name: corn
### Title: Comparison of corn for new and standard variety
### Aliases: corn
### Keywords: datasets

### ** Examples

data(corn)
t.test(corn)



