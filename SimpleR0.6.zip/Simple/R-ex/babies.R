### Name: babies
### Title: Data set with Mothers and Babies data from Child Health and
###   Development Study
### Aliases: babies
### Keywords: datasets

### ** Examples

data(babies)
pairs(babies)



