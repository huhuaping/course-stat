### Name: cancer
### Title: cancer survival times
### Aliases: cancer
### Keywords: datasets

### ** Examples

data(cancer)
boxplot(cancer)



