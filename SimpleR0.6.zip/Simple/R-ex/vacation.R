### Name: vacation
### Title: vacation days
### Aliases: vacation
### Keywords: datasets

### ** Examples

data(vacation)
hist(vacation)



