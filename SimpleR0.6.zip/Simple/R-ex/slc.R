### Name: slc
### Title: Sodium-Lithium countertransport
### Aliases: slc
### Keywords: datasets

### ** Examples

data(slc)
hist(slc)



