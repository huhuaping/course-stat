### Name: simple.eda
### Title: Simple function to plot histogram, boxplot and normal plot
### Aliases: simple.eda
### Keywords: univar hplot

### ** Examples

  x<- rnorm(100,5,10)
  simple.eda(x)



