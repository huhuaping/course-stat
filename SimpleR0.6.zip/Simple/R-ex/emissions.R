### Name: emissions
### Title: CO2 emissions data and Gross Domestic product for 26 countries
### Aliases: emissions
### Keywords: datasets

### ** Examples

data(emissions)
plot(emissions)



