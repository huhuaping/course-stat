### Name: rat
### Title: Survival times of 20 rats exposed to radiation
### Aliases: rat
### Keywords: datasets

### ** Examples

data(rat)
hist(rat)



