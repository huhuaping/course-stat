### Name: chicken
### Title: weight gain of chickens fed 3 different rations
### Aliases: chicken
### Keywords: datasets

### ** Examples

data(chicken)
boxplot(chicken)



