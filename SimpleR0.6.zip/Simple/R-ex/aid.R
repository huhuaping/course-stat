### Name: aid
### Title: monthly payment for federal program
### Aliases: aid
### Keywords: datasets

### ** Examples

data(aid)
hist(aid)



