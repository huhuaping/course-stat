### Name: firstchi
### Title: Age of mother at birth of first child
### Aliases: firstchi
### Keywords: datasets

### ** Examples

data(firstchi)
hist(firstchi)



