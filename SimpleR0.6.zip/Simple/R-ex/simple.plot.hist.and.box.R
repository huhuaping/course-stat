### Name: simple.plot.hist.and.box
### Title: A function to plot both a histogram and a boxplot
### Aliases: simple.plot.hist.and.box
### Keywords: univar aplot

### ** Examples

x<-rnorm(100)
simple.plot.hist.and.box(x)



