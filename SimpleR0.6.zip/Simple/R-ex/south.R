### Name: south
### Title: Murder rates for 30 Southern US cities
### Aliases: south
### Keywords: datasets

### ** Examples

data(south)
hist(south)



