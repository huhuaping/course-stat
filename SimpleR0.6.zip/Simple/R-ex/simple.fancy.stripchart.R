### Name: simple.fancy.stripchart
### Title: Makes a fancier strip chart: plots means and a line
### Aliases: simple.fancy.stripchart
### Keywords: hplot

### ** Examples

x = rnorm(10);y=rnorm(10,1)
simple.fancy.stripchart(list(x=x,y=y))



