### Name: homedata
### Title: Maplewood NJ assessed values for years 1970 and 2000
### Aliases: homedata
### Keywords: datasets

### ** Examples

data(homedata)
plot(homedata)



