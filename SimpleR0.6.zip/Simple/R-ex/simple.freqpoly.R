### Name: simple.freqpoly
### Title: Simply plot histogram and frequency polygon
### Aliases: simple.freqpoly
### Keywords: univar hplot

### ** Examples

x <- rt(100,4)
simple.freqpoly(x)



