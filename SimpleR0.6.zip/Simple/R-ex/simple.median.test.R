### Name: simple.median.test
### Title: Do simple sign test for median - no ranks
### Aliases: simple.median.test
### Keywords: htest

### ** Examples

x<-c(12,2,17,25,52,8,1,12)
simple.median.test(x,20)



