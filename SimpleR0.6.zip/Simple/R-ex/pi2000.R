### Name: pi2000
### Title: first 2000 digits of pi
### Aliases: pi2000
### Keywords: datasets

### ** Examples

data(pi2000)
chisq.test(table(pi2000))



