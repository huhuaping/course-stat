### Name: chips
### Title: Measurements of chip wafers
### Aliases: chips
### Keywords: datasets

### ** Examples

data(chips)
boxplot(chips)



