### Name: malpract
### Title: malpractice settlements
### Aliases: malpract
### Keywords: datasets

### ** Examples

data(malpract)
boxplot(malpract)



