### Name: movies
### Title: Top 25 movies for June 2001
### Aliases: movies
### Keywords: datasets

### ** Examples

data(movies)
hist(movies[['current']])



