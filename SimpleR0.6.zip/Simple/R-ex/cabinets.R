### Name: cabinets
### Title: cost of cabinets from 2 suppliers
### Aliases: cabinets
### Keywords: datasets

### ** Examples

data(cabinets)
boxplot(cabinets)



