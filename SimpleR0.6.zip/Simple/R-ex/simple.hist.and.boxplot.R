### Name: simple.hist.and.boxplot
### Title: A function to plot both a histogram and a boxplot
### Aliases: simple.hist.and.boxplot simple.plot.hist.and.box
### Keywords: univar aplot

### ** Examples

x<-rnorm(100)
simple.hist.and.boxplot(x)



